class NavigationResponse {
  String tagToNav;
  NavigationResponse(String tag) {
    this.tagToNav = tag;
  }
}