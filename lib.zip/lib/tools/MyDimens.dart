class MyDimens {
  static const double titleBig = 30;
  static const double titleNormal = 25;
  static const double titleSmall = 20;
  static const double subtitleSmall = 10;
  static const double subtitleNormal = 12;
  static const double subtitleBig = 15;

  static const double iconSize = 20;

}