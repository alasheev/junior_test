class ActionsItemArguments {
  int actionId;
  ActionsItemArguments(this.actionId);
}