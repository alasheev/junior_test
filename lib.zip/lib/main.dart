import 'package:flutter/material.dart';
import 'package:junior_test/ui/actions/ActionsWidget.dart';
import 'package:junior_test/ui/actions/item/ActionsItemWidget.dart';

void main() {
  // runApp(MaterialApp(home: Scaffold(body: ActionsItemWidget(2))));
  runApp(MaterialApp(home: Scaffold(body: ActionsWidget())));
}
